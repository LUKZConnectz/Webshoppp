/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#080b13',
        surface: '#10151f',
        surface2: '#161c29',
        mint: '#8CFFC7',
        peri: '#7C93FF',
        amber: '#FFD37C',
        muted: '#8A93AC',
        line: 'rgba(232,236,245,0.08)',
      },
      fontFamily: {
        disp: ['"Space Grotesk"', 'sans-serif'],
        sans: ['"Noto Sans Thai"', 'Inter', 'sans-serif'],
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
    },
  },
  plugins: [],
};
