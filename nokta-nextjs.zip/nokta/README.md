# nokta — Link-in-bio demo (Next.js)

โปรเจกต์ตัวอย่างเว็บ "link in bio" แบบ nokta สร้างด้วย Next.js 14 (App Router) + Tailwind CSS
ทุกหน้าลิงก์ถึงกันและใช้งานได้จริงในฝั่ง frontend (ข้อมูลเก็บอยู่ใน React state เท่านั้น ยังไม่มีฐานข้อมูล/เซิร์ฟเวอร์จริง)

## วิธีรันบนเครื่องคุณ

ต้องมี [Node.js](https://nodejs.org) เวอร์ชัน 18 ขึ้นไปติดตั้งไว้ก่อน

```bash
cd nokta
npm install
npm run dev
```

แล้วเปิด http://localhost:3000

## โครงสร้างหน้า

- `/` — หน้า landing
- `/login`, `/register` — ฟอร์มเข้าสู่ระบบ/สมัคร (mock, ไม่มี auth จริง กด submit แล้วพาไป `/dashboard`)
- `/dashboard` — ภาพรวม (สถิติ, เหรียญตรา, Discord, กระเป๋าเงิน)
- `/dashboard/profile` — แก้ไขโปรไฟล์ พร้อมพรีวิว
- `/dashboard/appearance` — เลือกธีมสี/สไตล์
- `/dashboard/links` — เพิ่ม/ลบ/สลับเปิดปิด/จัดลำดับลิงก์
- `/dashboard/badges` — เหรียญตราที่ปลดล็อกแล้ว
- `/dashboard/widgets` — เปิด/ปิดวิดเจ็ตเสริม
- `/dashboard/songs` — จัดการเพลงประกอบโปรไฟล์
- `/dashboard/settings` — ตั้งค่าบัญชี
- `/u/[username]` — หน้าโปรไฟล์สาธารณะ (mock data, ยังไม่เชื่อมกับข้อมูลจริงจากแดชบอร์ด)

## สิ่งที่ยังไม่มี (ต้องทำต่อถ้าจะใช้งานจริง)

- ฐานข้อมูล/เซิร์ฟเวอร์ (เช่น Postgres + Prisma หรือ Supabase) เพื่อเก็บข้อมูลถาวร
- ระบบ authentication จริง (เช่น NextAuth.js)
- เชื่อมหน้า `/u/[username]` ให้ดึงข้อมูลจริงจากฐานข้อมูลแทน mock data
- ระบบชำระเงิน/เติมเงินจริง (เช่น Omise, Stripe)
