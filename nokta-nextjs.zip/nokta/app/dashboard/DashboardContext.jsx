'use client';

import { createContext, useContext, useState } from 'react';

const DashboardContext = createContext(null);

const initialLinks = [
  { id: 1, title: 'พอร์ตโฟลิโอ', url: 'https://example.com/portfolio', enabled: true },
  { id: 2, title: 'Instagram', url: 'https://instagram.com/pxom', enabled: true },
  { id: 3, title: 'สั่งงานภาพประกอบ', url: 'https://example.com/commission', enabled: false },
];

const initialBadges = [
  { id: 1, name: 'ผู้บุกเบิก', unlocked: true },
  { id: 2, name: 'ครบ 7 วัน', unlocked: true },
  { id: 3, name: 'ยอดวิว 1,000', unlocked: false },
  { id: 4, name: 'ลิงก์ 10 อัน', unlocked: false },
  { id: 5, name: 'อัปเกรด Premium', unlocked: false },
  { id: 6, name: 'ธีมกำหนดเอง', unlocked: false },
  { id: 7, name: 'เพื่อน 5 คน', unlocked: false },
  { id: 8, name: 'ครบ 30 วัน', unlocked: false },
  { id: 9, name: 'นักสะสม', unlocked: false },
  { id: 10, name: 'ตำนาน', unlocked: false },
];

export function DashboardProvider({ children }) {
  const [profile, setProfile] = useState({
    username: 'pxom',
    displayName: 'Fahsai',
    bio: 'นักวาดภาพประกอบ · กรุงเทพฯ',
    plan: 'ฟรี',
    accent: 'mint',
  });
  const [links, setLinks] = useState(initialLinks);
  const [badges] = useState(initialBadges);
  const [songs, setSongs] = useState([{ id: 1, title: 'Golden Hour', artist: 'JVKE' }]);
  const [widgets, setWidgets] = useState({ discord: true, spotify: false, visitorCounter: true });
  const [wallet, setWallet] = useState(0);
  const [theme, setTheme] = useState({ accent: 'mint', style: 'dark' });

  const value = {
    profile,
    setProfile,
    links,
    setLinks,
    badges,
    songs,
    setSongs,
    widgets,
    setWidgets,
    wallet,
    setWallet,
    theme,
    setTheme,
  };

  return <DashboardContext.Provider value={value}>{children}</DashboardContext.Provider>;
}

export function useDashboard() {
  const ctx = useContext(DashboardContext);
  if (!ctx) throw new Error('useDashboard must be used within DashboardProvider');
  return ctx;
}
