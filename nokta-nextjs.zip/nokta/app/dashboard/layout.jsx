'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { DashboardProvider, useDashboard } from './DashboardContext';

const navSections = [
  {
    label: 'แดชบอร์ด',
    items: [{ href: '/dashboard', label: 'ภาพรวม', icon: '📊' }],
  },
  {
    label: 'ปรับแต่ง',
    items: [
      { href: '/dashboard/profile', label: 'โปรไฟล์', icon: '👤' },
      { href: '/dashboard/appearance', label: 'รูปลักษณ์', icon: '🎨' },
      { href: '/dashboard/links', label: 'ลิงก์', icon: '🔗' },
      { href: '/dashboard/badges', label: 'เหรียญตรา', icon: '🛡️' },
      { href: '/dashboard/widgets', label: 'วิดเจ็ต', icon: '🧩' },
      { href: '/dashboard/songs', label: 'เพลง', icon: '🎵' },
    ],
  },
  {
    label: 'จัดการ',
    items: [{ href: '/dashboard/settings', label: 'ตั้งค่า', icon: '⚙️' }],
  },
];

function SidebarLink({ href, label, icon }) {
  const pathname = usePathname();
  const active = pathname === href;
  return (
    <Link
      href={href}
      className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors ${
        active ? 'bg-mint/10 text-mint border border-mint/20' : 'text-muted hover:text-white hover:bg-white/[0.04]'
      }`}
    >
      <span className="text-base leading-none">{icon}</span>
      {label}
    </Link>
  );
}

function Sidebar() {
  const { profile } = useDashboard();
  return (
    <aside className="w-64 shrink-0 border-r border-line px-4 py-6 flex flex-col h-screen sticky top-0">
      <Link href="/" className="flex items-center gap-2.5 px-2 mb-8">
        <span className="w-7 h-7 rounded-full bg-gradient-to-br from-mint to-peri flex items-center justify-center">
          <span className="w-2 h-2 rounded-full bg-bg" />
        </span>
        <span className="font-disp font-bold text-lg tracking-tight text-white">nokta</span>
      </Link>

      <nav className="flex-1 space-y-6 overflow-y-auto">
        {navSections.map((section) => (
          <div key={section.label}>
            <div className="text-[10px] font-semibold uppercase tracking-widest text-muted/70 px-3 mb-2">
              {section.label}
            </div>
            <div className="space-y-1">
              {section.items.map((item) => (
                <SidebarLink key={item.href} {...item} />
              ))}
            </div>
          </div>
        ))}
      </nav>

      <Link
        href="/"
        className="mt-4 flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-white text-sm font-medium rounded-xl py-2.5 transition-colors"
      >
        ↩ กลับหน้าหลัก
      </Link>

      <div className="mt-4 flex items-center gap-3 px-2 pt-4 border-t border-line">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-mint to-peri shrink-0" />
        <div className="min-w-0">
          <div className="text-sm font-medium text-white truncate">@{profile.username}</div>
          <div className="text-xs text-muted">แพ็กเกจ{profile.plan}</div>
        </div>
      </div>
    </aside>
  );
}

function TopBar() {
  return (
    <div className="flex items-center justify-end px-8 py-5 border-b border-line">
      <Link
        href="/dashboard/settings"
        className="inline-flex items-center gap-2 bg-gradient-to-r from-mint to-peri text-bg text-sm font-semibold px-4 py-2 rounded-full hover:opacity-90 transition-opacity"
      >
        ◆ อัปเกรด Premium
      </Link>
    </div>
  );
}

export default function DashboardLayout({ children }) {
  return (
    <DashboardProvider>
      <div className="min-h-screen bg-bg flex">
        <Sidebar />
        <div className="flex-1 min-w-0">
          <TopBar />
          <main className="px-8 py-8 max-w-5xl">{children}</main>
        </div>
      </div>
    </DashboardProvider>
  );
}
