'use client';

import { useDashboard } from '../DashboardContext';

const widgetList = [
  { key: 'discord', label: 'Discord กำลังเล่น', desc: 'แสดงสถานะ Discord ปัจจุบันของคุณบนหน้าโปรไฟล์', icon: '🎮' },
  { key: 'spotify', label: 'Spotify กำลังเล่น', desc: 'โชว์เพลงที่คุณกำลังฟังอยู่แบบเรียลไทม์', icon: '🎧' },
  { key: 'visitorCounter', label: 'ตัวนับผู้เข้าชม', desc: 'แสดงจำนวนคนที่เข้ามาดูโปรไฟล์คุณ', icon: '👁️' },
];

export default function WidgetsPage() {
  const { widgets, setWidgets } = useDashboard();

  function toggle(key) {
    setWidgets((w) => ({ ...w, [key]: !w[key] }));
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-disp text-2xl font-bold text-white mb-1">วิดเจ็ต</h1>
        <p className="text-sm text-muted">เปิด/ปิดองค์ประกอบเสริมที่แสดงบนหน้าโปรไฟล์ของคุณ</p>
      </div>

      <div className="space-y-3">
        {widgetList.map((w) => (
          <div
            key={w.key}
            className="border border-line bg-surface rounded-2xl px-6 py-5 flex items-center justify-between gap-4"
          >
            <div className="flex items-center gap-4 min-w-0">
              <div className="w-10 h-10 rounded-lg bg-mint/10 flex items-center justify-center text-lg shrink-0">
                {w.icon}
              </div>
              <div className="min-w-0">
                <div className="text-sm font-medium text-white">{w.label}</div>
                <div className="text-xs text-muted mt-0.5">{w.desc}</div>
              </div>
            </div>
            <label className="inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={widgets[w.key]}
                onChange={() => toggle(w.key)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-white/10 rounded-full peer peer-checked:bg-mint transition-colors relative">
                <div className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform peer-checked:translate-x-5" />
              </div>
            </label>
          </div>
        ))}
      </div>
    </div>
  );
}
