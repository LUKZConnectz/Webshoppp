'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useDashboard } from './DashboardContext';

function StatCard({ icon, value, label }) {
  return (
    <div className="border border-line bg-surface rounded-2xl p-5 flex items-start justify-between">
      <div>
        <div className="w-9 h-9 rounded-lg bg-mint/10 flex items-center justify-center text-mint mb-4">{icon}</div>
        <div className="font-disp text-2xl font-bold text-white">{value}</div>
        <div className="text-xs text-muted mt-1">{label}</div>
      </div>
    </div>
  );
}

export default function OverviewPage() {
  const { profile, links, badges, wallet, setWallet } = useDashboard();
  const [showTopup, setShowTopup] = useState(false);
  const unlockedBadges = badges.filter((b) => b.unlocked).length;

  function handleTopup(amount) {
    setWallet((w) => w + amount);
    setShowTopup(false);
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-disp text-2xl font-bold text-white mb-1">ภาพรวม</h1>
        <p className="text-sm text-muted">สรุปสถานะหน้าโปรไฟล์ของคุณ</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon="👁️" value="1" label="ยอดเข้าชมโปรไฟล์" />
        <StatCard icon="🔗" value={links.length} label="ลิงก์ทั้งหมด" />
        <StatCard icon="🛡️" value={`${unlockedBadges}/${badges.length}`} label="เหรียญตรา" />
        <StatCard icon="👤" value={profile.plan} label="แพ็กเกจปัจจุบัน" />
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 border border-line bg-surface rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-white flex items-center gap-2">🛡️ เหรียญตราจำนวนจำกัด</h2>
            <Link href="/dashboard/badges" className="text-xs text-muted hover:text-white transition-colors">
              ดูทั้งหมด
            </Link>
          </div>
          <p className="text-sm text-muted mb-4">สะสม badge พิเศษจำนวนจำกัด</p>
          {unlockedBadges === 0 ? (
            <p className="text-sm text-white/80 mb-4">🛡️ ยังไม่มี Badges — ไปรับได้เลย!</p>
          ) : (
            <p className="text-sm text-white/80 mb-4">ปลดล็อกแล้ว {unlockedBadges} เหรียญ</p>
          )}
          <div className="h-2 rounded-full bg-white/[0.06] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-mint to-peri rounded-full"
              style={{ width: `${(unlockedBadges / badges.length) * 100}%` }}
            />
          </div>
          <div className="text-xs text-muted mt-2">
            {unlockedBadges} / {badges.length} เหรียญตรา
          </div>
        </div>

        <div className="border border-line bg-surface rounded-2xl p-6">
          <div className="w-10 h-10 rounded-lg bg-[#5865F2]/15 flex items-center justify-center text-[#5865F2] mb-4">
            🎮
          </div>
          <h3 className="font-semibold text-white mb-1">เข้าร่วม Discord ของเรา</h3>
          <p className="text-xs text-muted mb-4">discord.gg</p>
          <a
            href="https://discord.gg"
            target="_blank"
            rel="noreferrer"
            className="block text-center bg-[#5865F2] text-white text-sm font-medium rounded-xl py-2.5 hover:opacity-90 transition-opacity"
          >
            🎮 เข้าร่วม Discord
          </a>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="border border-line bg-surface rounded-2xl p-6">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2">👁️ โปรไฟล์ของคุณ</h3>
          <div className="text-sm text-muted mb-4">
            nokta.co/<span className="text-white font-medium">{profile.username}</span>
          </div>
          <Link
            href={`/u/${profile.username}`}
            className="block text-center border border-line text-white text-sm font-medium rounded-xl py-2.5 hover:bg-white/5 transition-colors"
          >
            ดูโปรไฟล์ ↗
          </Link>
        </div>

        <div className="lg:col-span-2 border border-line bg-surface rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-white flex items-center gap-2">👁️ กราฟยอดการดู</h3>
            <span className="text-xs text-muted">7 วันล่าสุด</span>
          </div>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <div className="text-xs text-muted">ยอดรวมทั้งหมด</div>
              <div className="font-disp text-xl font-bold text-white">1</div>
            </div>
            <div>
              <div className="text-xs text-muted">7 วันล่าสุด</div>
              <div className="font-disp text-xl font-bold text-white">0</div>
            </div>
          </div>
          <div className="h-20 flex items-end gap-2">
            {[10, 4, 0, 0, 0, 0, 0].map((v, i) => (
              <div key={i} className="flex-1 bg-white/[0.06] rounded-t-md relative" style={{ height: '100%' }}>
                <div
                  className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-mint to-peri rounded-t-md"
                  style={{ height: `${v * 8}%` }}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="border border-line bg-surface rounded-2xl p-6 flex items-center justify-between">
        <div>
          <div className="text-sm text-muted mb-1">กระเป๋าเงิน</div>
          <div className="font-disp text-3xl font-bold text-white">฿{wallet.toFixed(2)}</div>
        </div>
        <button
          onClick={() => setShowTopup(true)}
          className="bg-gradient-to-r from-mint to-peri text-bg text-sm font-semibold px-6 py-2.5 rounded-full hover:opacity-90 transition-opacity"
        >
          เติมเงิน
        </button>
      </div>

      {showTopup && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 px-6">
          <div className="border border-line bg-surface rounded-2xl p-6 w-full max-w-sm">
            <h3 className="font-semibold text-white mb-4">เลือกจำนวนเงินที่เติม</h3>
            <div className="grid grid-cols-3 gap-2 mb-5">
              {[50, 100, 300].map((amt) => (
                <button
                  key={amt}
                  onClick={() => handleTopup(amt)}
                  className="border border-line rounded-xl py-3 text-sm text-white hover:border-mint/50 hover:bg-mint/5 transition-colors"
                >
                  ฿{amt}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowTopup(false)}
              className="w-full text-sm text-muted hover:text-white transition-colors py-2"
            >
              ยกเลิก
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
