'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useDashboard } from '../DashboardContext';

export default function SettingsPage() {
  const router = useRouter();
  const { profile } = useDashboard();
  const [email, setEmail] = useState('you@example.com');
  const [password, setPassword] = useState('');
  const [saved, setSaved] = useState(false);

  function handleSave(e) {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  function handleDelete() {
    const ok = window.confirm('ยืนยันการลบบัญชีถาวร? การกระทำนี้ไม่สามารถย้อนกลับได้');
    if (ok) router.push('/');
  }

  return (
    <div className="space-y-8 max-w-2xl">
      <div>
        <h1 className="font-disp text-2xl font-bold text-white mb-1">ตั้งค่า</h1>
        <p className="text-sm text-muted">จัดการบัญชีและความปลอดภัยของคุณ</p>
      </div>

      <form onSubmit={handleSave} className="border border-line bg-surface rounded-2xl p-6 space-y-5">
        <h2 className="font-semibold text-white">บัญชี</h2>
        <div>
          <label className="block text-xs text-muted mb-1.5">ชื่อผู้ใช้</label>
          <input
            value={profile.username}
            disabled
            className="w-full border border-line rounded-xl px-4 py-2.5 text-sm text-muted bg-white/[0.02] outline-none cursor-not-allowed"
          />
        </div>
        <div>
          <label className="block text-xs text-muted mb-1.5">อีเมล</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50"
          />
        </div>
        <div>
          <label className="block text-xs text-muted mb-1.5">รหัสผ่านใหม่</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="เว้นว่างไว้หากไม่ต้องการเปลี่ยน"
            className="w-full border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50"
          />
        </div>
        <button
          type="submit"
          className="bg-white text-bg font-medium rounded-full px-6 py-2.5 text-sm hover:bg-mint transition-colors"
        >
          บันทึกการเปลี่ยนแปลง
        </button>
        {saved && <span className="ml-3 text-xs text-mint">บันทึกแล้ว ✓</span>}
      </form>

      <div className="border border-red-500/20 bg-red-500/[0.03] rounded-2xl p-6">
        <h2 className="font-semibold text-red-400 mb-1">โซนอันตราย</h2>
        <p className="text-sm text-muted mb-4">การลบบัญชีจะลบข้อมูลทั้งหมดอย่างถาวรและไม่สามารถกู้คืนได้</p>
        <button
          onClick={handleDelete}
          className="border border-red-500/30 text-red-400 text-sm font-medium rounded-full px-5 py-2 hover:bg-red-500/10 transition-colors"
        >
          ลบบัญชีของฉัน
        </button>
      </div>
    </div>
  );
}
