'use client';

import { useState } from 'react';
import { useDashboard } from '../DashboardContext';

export default function LinksPage() {
  const { links, setLinks } = useDashboard();
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');

  function addLink(e) {
    e.preventDefault();
    if (!title.trim() || !url.trim()) return;
    setLinks((prev) => [...prev, { id: Date.now(), title, url, enabled: true }]);
    setTitle('');
    setUrl('');
  }

  function removeLink(id) {
    setLinks((prev) => prev.filter((l) => l.id !== id));
  }

  function toggleLink(id) {
    setLinks((prev) => prev.map((l) => (l.id === id ? { ...l, enabled: !l.enabled } : l)));
  }

  function move(id, dir) {
    setLinks((prev) => {
      const idx = prev.findIndex((l) => l.id === id);
      const newIdx = idx + dir;
      if (newIdx < 0 || newIdx >= prev.length) return prev;
      const copy = [...prev];
      [copy[idx], copy[newIdx]] = [copy[newIdx], copy[idx]];
      return copy;
    });
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-disp text-2xl font-bold text-white mb-1">ลิงก์</h1>
        <p className="text-sm text-muted">เพิ่ม จัดลำดับ และเปิด/ปิดลิงก์ที่แสดงบนหน้าโปรไฟล์ของคุณ</p>
      </div>

      <form onSubmit={addLink} className="border border-line bg-surface rounded-2xl p-6 grid sm:grid-cols-[1fr_1.5fr_auto] gap-3">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="ชื่อลิงก์ เช่น Instagram"
          className="border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50"
        />
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://..."
          className="border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50"
        />
        <button
          type="submit"
          className="bg-white text-bg font-medium rounded-xl px-6 py-2.5 text-sm hover:bg-mint transition-colors whitespace-nowrap"
        >
          + เพิ่มลิงก์
        </button>
      </form>

      <div className="space-y-3">
        {links.length === 0 && (
          <div className="text-center text-sm text-muted border border-dashed border-line rounded-2xl py-12">
            ยังไม่มีลิงก์ — เพิ่มลิงก์แรกของคุณด้านบน
          </div>
        )}
        {links.map((link, i) => (
          <div
            key={link.id}
            className="border border-line bg-surface rounded-2xl px-5 py-4 flex items-center gap-4"
          >
            <div className="flex flex-col gap-1">
              <button
                onClick={() => move(link.id, -1)}
                disabled={i === 0}
                className="text-muted hover:text-white disabled:opacity-20 transition-colors text-xs"
              >
                ▲
              </button>
              <button
                onClick={() => move(link.id, 1)}
                disabled={i === links.length - 1}
                className="text-muted hover:text-white disabled:opacity-20 transition-colors text-xs"
              >
                ▼
              </button>
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-medium text-white truncate">{link.title}</div>
              <div className="text-xs text-muted truncate">{link.url}</div>
            </div>
            <label className="inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={link.enabled}
                onChange={() => toggleLink(link.id)}
                className="sr-only peer"
              />
              <div className="w-10 h-6 bg-white/10 rounded-full peer peer-checked:bg-mint transition-colors relative">
                <div className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform peer-checked:translate-x-4" />
              </div>
            </label>
            <button
              onClick={() => removeLink(link.id)}
              className="text-muted hover:text-red-400 transition-colors shrink-0 text-sm"
            >
              ลบ
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
