'use client';

import { useDashboard } from '../DashboardContext';

export default function BadgesPage() {
  const { badges } = useDashboard();
  const unlocked = badges.filter((b) => b.unlocked).length;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-disp text-2xl font-bold text-white mb-1">เหรียญตรา</h1>
        <p className="text-sm text-muted">
          ปลดล็อกแล้ว {unlocked} จาก {badges.length} เหรียญ
        </p>
      </div>

      <div className="border border-line bg-surface rounded-2xl p-6">
        <div className="h-2 rounded-full bg-white/[0.06] overflow-hidden mb-6">
          <div
            className="h-full bg-gradient-to-r from-mint to-peri rounded-full transition-all"
            style={{ width: `${(unlocked / badges.length) * 100}%` }}
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {badges.map((b) => (
            <div
              key={b.id}
              className={`rounded-2xl border p-4 flex flex-col items-center text-center gap-2 ${
                b.unlocked ? 'border-mint/30 bg-mint/5' : 'border-line bg-white/[0.02] opacity-60'
              }`}
            >
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center text-xl ${
                  b.unlocked ? 'bg-gradient-to-br from-mint to-peri' : 'bg-white/5'
                }`}
              >
                {b.unlocked ? '🛡️' : '🔒'}
              </div>
              <div className="text-xs text-white font-medium">{b.name}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
