'use client';

import { useDashboard } from '../DashboardContext';

const accents = [
  { id: 'mint', label: 'มินต์', className: 'from-mint to-peri' },
  { id: 'amber', label: 'อำพัน', className: 'from-amber to-mint' },
  { id: 'rose', label: 'กุหลาบ', className: 'from-pink-400 to-peri' },
  { id: 'peri', label: 'พีริวิงเคิล', className: 'from-peri to-mint' },
];

const styles = [
  { id: 'dark', label: 'มืด (Dark)' },
  { id: 'gradient', label: 'ไล่เฉด (Gradient)' },
  { id: 'minimal', label: 'มินิมอล' },
];

export default function AppearancePage() {
  const { theme, setTheme, profile } = useDashboard();
  const selectedAccent = accents.find((a) => a.id === theme.accent) ?? accents[0];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-disp text-2xl font-bold text-white mb-1">รูปลักษณ์</h1>
        <p className="text-sm text-muted">ปรับสีและสไตล์พื้นหลังของหน้าโปรไฟล์</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="border border-line bg-surface rounded-2xl p-6">
            <h3 className="font-semibold text-white mb-4">สีหลัก (Accent)</h3>
            <div className="grid grid-cols-4 gap-3">
              {accents.map((a) => (
                <button
                  key={a.id}
                  onClick={() => setTheme((t) => ({ ...t, accent: a.id }))}
                  className={`rounded-2xl p-3 border transition-colors ${
                    theme.accent === a.id ? 'border-mint' : 'border-line hover:border-white/20'
                  }`}
                >
                  <div className={`h-10 rounded-lg bg-gradient-to-r ${a.className} mb-2`} />
                  <div className="text-xs text-white">{a.label}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="border border-line bg-surface rounded-2xl p-6">
            <h3 className="font-semibold text-white mb-4">สไตล์พื้นหลัง</h3>
            <div className="space-y-2">
              {styles.map((s) => (
                <label
                  key={s.id}
                  className={`flex items-center justify-between border rounded-xl px-4 py-3 cursor-pointer transition-colors ${
                    theme.style === s.id ? 'border-mint bg-mint/5' : 'border-line hover:bg-white/[0.03]'
                  }`}
                >
                  <span className="text-sm text-white">{s.label}</span>
                  <input
                    type="radio"
                    name="style"
                    checked={theme.style === s.id}
                    onChange={() => setTheme((t) => ({ ...t, style: s.id }))}
                    className="accent-mint"
                  />
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="border border-line bg-surface rounded-2xl p-6">
          <div className="text-xs text-muted mb-4">ตัวอย่างธีม</div>
          <div className="rounded-2xl bg-gradient-to-b from-surface2 to-bg border border-line p-6 flex flex-col items-center text-center">
            <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${selectedAccent.className} mb-3`} />
            <div className="font-disp font-semibold text-white">{profile.displayName}</div>
            <div className="text-xs text-muted mt-1 mb-4">@{profile.username}</div>
            <div className="w-full space-y-2">
              {['ลิงก์ตัวอย่าง', 'ลิงก์ตัวอย่าง 2'].map((l) => (
                <div
                  key={l}
                  className={`rounded-xl px-4 py-2.5 text-xs text-white border ${
                    theme.style === 'gradient'
                      ? `bg-gradient-to-r ${selectedAccent.className} bg-opacity-10 border-transparent`
                      : 'border-line bg-white/[0.03]'
                  }`}
                >
                  {l}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
