'use client';

import { useState } from 'react';
import { useDashboard } from '../DashboardContext';

export default function SongsPage() {
  const { songs, setSongs } = useDashboard();
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');

  function addSong(e) {
    e.preventDefault();
    if (!title.trim()) return;
    setSongs((prev) => [...prev, { id: Date.now(), title, artist }]);
    setTitle('');
    setArtist('');
  }

  function removeSong(id) {
    setSongs((prev) => prev.filter((s) => s.id !== id));
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-disp text-2xl font-bold text-white mb-1">เพลง</h1>
        <p className="text-sm text-muted">เพิ่มเพลงที่จะเล่นประกอบหน้าโปรไฟล์ของคุณ</p>
      </div>

      <form onSubmit={addSong} className="border border-line bg-surface rounded-2xl p-6 grid sm:grid-cols-[1fr_1fr_auto] gap-3">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="ชื่อเพลง"
          className="border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50"
        />
        <input
          value={artist}
          onChange={(e) => setArtist(e.target.value)}
          placeholder="ศิลปิน"
          className="border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50"
        />
        <button
          type="submit"
          className="bg-white text-bg font-medium rounded-xl px-6 py-2.5 text-sm hover:bg-mint transition-colors whitespace-nowrap"
        >
          + เพิ่มเพลง
        </button>
      </form>

      <div className="space-y-3">
        {songs.length === 0 && (
          <div className="text-center text-sm text-muted border border-dashed border-line rounded-2xl py-12">
            ยังไม่มีเพลง — เพิ่มเพลงแรกของคุณด้านบน
          </div>
        )}
        {songs.map((s) => (
          <div key={s.id} className="border border-line bg-surface rounded-2xl px-5 py-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-mint to-peri flex items-center justify-center text-bg shrink-0">
              🎵
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-medium text-white truncate">{s.title}</div>
              {s.artist && <div className="text-xs text-muted truncate">{s.artist}</div>}
            </div>
            <button
              onClick={() => removeSong(s.id)}
              className="text-muted hover:text-red-400 transition-colors shrink-0 text-sm"
            >
              ลบ
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
