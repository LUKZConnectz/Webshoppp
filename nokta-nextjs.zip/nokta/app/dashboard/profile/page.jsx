'use client';

import { useState } from 'react';
import { useDashboard } from '../DashboardContext';

export default function ProfilePage() {
  const { profile, setProfile } = useDashboard();
  const [form, setForm] = useState(profile);
  const [saved, setSaved] = useState(false);

  function handleChange(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
    setSaved(false);
  }

  function handleSave(e) {
    e.preventDefault();
    setProfile(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-disp text-2xl font-bold text-white mb-1">โปรไฟล์</h1>
        <p className="text-sm text-muted">แก้ไขข้อมูลที่แสดงบนหน้าโปรไฟล์สาธารณะของคุณ</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <form onSubmit={handleSave} className="lg:col-span-2 border border-line bg-surface rounded-2xl p-6 space-y-5">
          <div>
            <label className="block text-xs text-muted mb-1.5">ชื่อผู้ใช้ (URL)</label>
            <div className="flex items-center border border-line rounded-xl overflow-hidden focus-within:border-mint/50">
              <span className="px-3 text-xs text-muted border-r border-line py-2.5 shrink-0">nokta.co/</span>
              <input
                value={form.username}
                onChange={(e) => handleChange('username', e.target.value)}
                className="w-full px-3 py-2.5 text-sm text-white outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs text-muted mb-1.5">ชื่อที่แสดง</label>
            <input
              value={form.displayName}
              onChange={(e) => handleChange('displayName', e.target.value)}
              className="w-full border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50"
            />
          </div>
          <div>
            <label className="block text-xs text-muted mb-1.5">คำอธิบายตัวคุณ (Bio)</label>
            <textarea
              value={form.bio}
              onChange={(e) => handleChange('bio', e.target.value)}
              rows={3}
              className="w-full border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50 resize-none"
            />
          </div>
          <button
            type="submit"
            className="bg-white text-bg font-medium rounded-full px-6 py-2.5 text-sm hover:bg-mint transition-colors"
          >
            บันทึกการเปลี่ยนแปลง
          </button>
          {saved && <span className="ml-3 text-xs text-mint">บันทึกแล้ว ✓</span>}
        </form>

        <div className="border border-line bg-surface rounded-2xl p-6">
          <div className="text-xs text-muted mb-4">ตัวอย่างหน้าโปรไฟล์</div>
          <div className="rounded-2xl bg-gradient-to-b from-surface2 to-bg border border-line p-6 flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-mint to-peri mb-3" />
            <div className="font-disp font-semibold text-white">{form.displayName || 'ชื่อของคุณ'}</div>
            <div className="text-xs text-muted mt-1">@{form.username || 'username'}</div>
            <div className="text-xs text-muted mt-3">{form.bio}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
