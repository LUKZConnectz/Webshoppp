'use client';

import Link from 'next/link';

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-bg">
      {/* NAV */}
      <nav className="fixed top-0 inset-x-0 z-40 backdrop-blur-md bg-bg/70 border-b border-white/[0.06]">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="w-7 h-7 rounded-full bg-gradient-to-br from-mint to-peri flex items-center justify-center">
              <span className="w-2 h-2 rounded-full bg-bg" />
            </span>
            <span className="font-disp font-bold text-lg tracking-tight text-white">nokta</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/login" className="hidden sm:block text-sm text-muted hover:text-white transition-colors">
              เข้าสู่ระบบ
            </Link>
            <Link
              href="/register"
              className="text-sm font-medium bg-white text-bg px-4 py-2 rounded-full hover:bg-mint transition-colors"
            >
              เริ่มใช้งานฟรี
            </Link>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <header className="relative pt-40 pb-28 px-6 overflow-hidden">
        <div className="absolute top-[-10%] left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-peri/10 rounded-full blur-[140px] pointer-events-none" />
        <div className="max-w-6xl mx-auto relative">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-medium text-muted border border-white/10 rounded-full px-3 py-1.5 mb-8">
                <span className="w-1.5 h-1.5 rounded-full bg-mint pulse-dot" />
                จุดเดียว ที่รวมทุกตัวตนของคุณ
              </div>
              <h1 className="font-disp text-5xl md:text-6xl font-bold leading-[1.05] tracking-tight mb-6 text-white">
                ลิงก์เยอะแยะ
                <br />
                ให้เหลือแค่
                <br />
                <span className="bg-gradient-to-r from-mint to-peri bg-clip-text text-transparent">จุดเดียว</span>
              </h1>
              <p className="text-muted text-base md:text-lg leading-relaxed max-w-md mb-10">
                สร้างหน้าโปรไฟล์ของคุณเองใน 2 นาที รวมโซเชียล ผลงาน ร้านค้า และลิงก์ทั้งหมด ไว้ในที่อยู่เดียวที่จำง่าย
              </p>
              <div className="flex flex-wrap items-center gap-4">
                <Link
                  href="/register"
                  className="group inline-flex items-center gap-2 bg-white text-bg font-medium px-6 py-3.5 rounded-full hover:bg-mint transition-all"
                >
                  สร้างหน้าของคุณ
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M5 12h14M13 5l7 7-7 7" />
                  </svg>
                </Link>
                <Link href="/dashboard" className="text-sm text-muted hover:text-white transition-colors px-2">
                  ดูตัวอย่างแดชบอร์ด →
                </Link>
              </div>
            </div>

            <div className="relative flex justify-center lg:justify-end">
              <div className="w-[280px] rounded-[2.5rem] border border-white/10 bg-surface p-3">
                <div className="rounded-[2rem] overflow-hidden bg-gradient-to-b from-surface to-bg p-6 pt-10 min-h-[460px]">
                  <div className="flex flex-col items-center text-center mb-6">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-mint to-peri mb-3" />
                    <div className="font-disp font-semibold text-sm text-white">@fahsai.creates</div>
                    <div className="text-xs text-muted mt-1">นักวาดภาพประกอบ · กรุงเทพฯ</div>
                  </div>
                  <div className="space-y-2.5">
                    {['พอร์ตโฟลิโอ', 'สั่งงานภาพประกอบ', 'Instagram', 'สนับสนุนผลงาน'].map((l) => (
                      <div
                        key={l}
                        className="border border-line bg-white/[0.03] rounded-xl px-4 py-3 text-xs font-medium flex items-center justify-between text-white"
                      >
                        <span>{l}</span>
                        <span className="text-muted">→</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* FEATURES */}
      <section className="px-6 py-24 max-w-6xl mx-auto">
        <div className="max-w-lg mb-16">
          <div className="text-xs font-medium text-mint tracking-widest uppercase mb-4">สร้างใน 3 ขั้นตอน</div>
          <h2 className="font-disp text-3xl md:text-4xl font-bold tracking-tight text-white">
            จากไม่มีอะไรเลย ถึงหน้าโปรไฟล์ที่ใช้จริง
          </h2>
        </div>
        <div className="grid md:grid-cols-3 gap-px bg-white/[0.06] rounded-2xl overflow-hidden">
          {[
            ['01', 'เลือกชื่อของคุณ', 'จองที่อยู่ nokta.co/ชื่อคุณ ให้คนจำได้ในครั้งเดียว'],
            ['02', 'ใส่ลิงก์ที่สำคัญ', 'จัดลำดับลิงก์โซเชียล ร้านค้า หรือผลงาน ได้ตามใจ'],
            ['03', 'ปรับธีมให้เป็นคุณ', 'เลือกสีและพื้นหลัง ให้ตรงกับตัวตนของคุณ แล้วแชร์ได้เลย'],
          ].map(([n, t, d]) => (
            <div key={n} className="bg-bg p-8">
              <div className="font-disp text-5xl font-bold text-white/10 mb-6">{n}</div>
              <h3 className="font-semibold text-lg mb-2 text-white">{t}</h3>
              <p className="text-sm text-muted leading-relaxed">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 pb-28 max-w-6xl mx-auto">
        <div className="border border-line rounded-3xl p-14 text-center bg-gradient-to-b from-surface2 to-bg relative overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-mint/10 rounded-full blur-[120px]" />
          <h2 className="font-disp text-3xl md:text-4xl font-bold tracking-tight mb-4 relative text-white">
            พร้อมรวมทุกอย่างไว้ที่เดียวหรือยัง?
          </h2>
          <p className="text-muted mb-8 relative">จองชื่อของคุณวันนี้ ก่อนคนอื่นจะใช้ไปก่อน</p>
          <Link
            href="/register"
            className="relative inline-flex items-center gap-2 bg-white text-bg font-medium px-7 py-3.5 rounded-full hover:bg-mint transition-all"
          >
            สร้างหน้าของคุณฟรี
          </Link>
        </div>
      </section>

      <footer className="border-t border-white/[0.06] px-6 py-10">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-gradient-to-br from-mint to-peri" />
            <span className="font-disp font-semibold text-white">nokta</span>
            <span>© 2026</span>
          </div>
        </div>
      </footer>
    </main>
  );
}
