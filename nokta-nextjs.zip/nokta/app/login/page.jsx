'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    // Demo only: no real auth, just go to the dashboard.
    router.push('/dashboard');
  }

  return (
    <main className="min-h-screen bg-bg flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <Link href="/" className="flex items-center justify-center gap-2.5 mb-10">
          <span className="w-7 h-7 rounded-full bg-gradient-to-br from-mint to-peri flex items-center justify-center">
            <span className="w-2 h-2 rounded-full bg-bg" />
          </span>
          <span className="font-disp font-bold text-lg tracking-tight text-white">nokta</span>
        </Link>

        <div className="border border-line bg-surface rounded-3xl p-8">
          <h1 className="font-disp text-2xl font-bold text-white mb-1">เข้าสู่ระบบ</h1>
          <p className="text-sm text-muted mb-6">ยินดีต้อนรับกลับมา</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs text-muted mb-1.5">อีเมล</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50 transition-colors"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="block text-xs text-muted mb-1.5">รหัสผ่าน</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-line rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-mint/50 transition-colors"
                placeholder="••••••••"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-white text-bg font-medium rounded-full py-2.5 text-sm hover:bg-mint transition-colors"
            >
              เข้าสู่ระบบ
            </button>
          </form>

          <p className="text-xs text-muted text-center mt-6">
            ยังไม่มีบัญชี?{' '}
            <Link href="/register" className="text-mint hover:underline">
              สมัครสมาชิก
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}
