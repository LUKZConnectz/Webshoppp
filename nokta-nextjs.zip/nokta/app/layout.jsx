import './globals.css';

export const metadata = {
  title: 'nokta — ทุกตัวตนของคุณ ในลิงก์เดียว',
  description: 'สร้างหน้าโปรไฟล์ลิงก์ของคุณได้ง่าย จัดวางสวย และปรับแต่งได้ไวในไม่กี่คลิก',
};

export default function RootLayout({ children }) {
  return (
    <html lang="th">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
